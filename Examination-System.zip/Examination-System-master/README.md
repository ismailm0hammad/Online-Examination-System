# Online-Examination-System
This project is developed using java server pages (jsp) and MySQL is used for backend.
IDE is the Netbeans.
sql script is included in "db script" folder.
Please create:
exam_system as a database schema.

database settings are in DatabaseClass.java.
you can modify it or default settings are:
db name:  exam_system
user:     root
pass:     (your db password)

insert your first user into the database and use the application.
Thanks
E:\mysql-connector-j-8.1.0\mysql-connector-j-8.1.0.jar
Change the properties in private.properties file
Change the properties in project.properties file:file.reference.mysql-connector-j-8.1.0.jar=E:\\mysql-connector-j-8.1.0.jar
change password: DatabaseClass.java